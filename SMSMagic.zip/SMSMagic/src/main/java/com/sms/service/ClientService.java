package com.sms.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.sms.dao.ClientRepository;
import com.sms.dao.CompanyRepository;
import com.sms.entity.Client;
import com.sms.entity.Company;

public class ClientService 
{

	 	@Autowired
	    private ClientRepository clientRepository;

	    @Autowired
	    private CompanyRepository companyRepository;

	    public Client createClient(Client client) {
	        Company company = client.getCompany();
	        if (companyRepository.existsById(company.getId())) {
	            return null; 
	        }

	        return clientRepository.save(client);
	    }
	    
	    public Client updateClient(Long clientId, Map<String, Object> updates) 
	    {
	        Client client = (Client) clientRepository.findById(clientId).orElse(null);
	        if (client != null) {
	           

	            return clientRepository.save(client);
	        } 
	        else 
	        {
	            return null;
	        }
	        
	    }
}
