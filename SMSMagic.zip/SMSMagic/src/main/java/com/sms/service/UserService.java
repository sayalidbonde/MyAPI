package com.sms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sms.dao.UserRepository;
import com.sms.entity.User;

@Service
public class UserService {

	@Autowired
    private UserRepository userRepository;

    public List<User> listUsers(String username) {
        if (username != null) {
            return userRepository.findByUsername(username);
        } else {
            return userRepository.findAll();
        }
    }
    
    public User updateUser(Long userId, User updatedUser) 
    {
        User user = userRepository.findById(userId).orElse(null);
        if (user != null) {
           
            user.setUsername(updatedUser.getUsername());
            return userRepository.save(user);
        } else {
            return null;
        }
    }
}
