package com.sms.dao;

import java.util.List;

import com.sms.entity.Company;

public interface CompanyCustomeRepository {

	List<Company> findCompaniesByEmpRange(int minEmp,int maxEmp);
	
	
}
