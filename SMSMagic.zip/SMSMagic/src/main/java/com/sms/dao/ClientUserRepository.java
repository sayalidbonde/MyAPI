package com.sms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sms.entity.ClientUser;
import com.sms.entity.User;

public interface ClientUserRepository extends JpaRepository<ClientUser, Long>{

	List<ClientUser> findByUser(List<User> user);
}
