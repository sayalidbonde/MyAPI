package com.sms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sms.entity.Company;

import ch.qos.logback.core.net.server.Client;

public interface ClientRepository extends JpaRepository<Client, Long>{

	Client findByCompany(Company company);

	public com.sms.entity.Client save(com.sms.entity.Client client);

}
