package com.sms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sms.entity.Company;

public interface CompanyRepository extends JpaRepository<Company, Long>{

}
