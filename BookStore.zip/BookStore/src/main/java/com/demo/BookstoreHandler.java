package com.demo;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.demo.entity.User;
import com.demo.service.UserService;


@Controller
public class BookstoreHandler {

	@Autowired
	private UserService userService;
	
	@GetMapping("/go")
	public String homePage()
	{
		return "index";
	}
	
	@GetMapping("/signin")
	public String userLogin()
	{
		return "login";
	}
	
	@GetMapping("/register")
	public String userRegister()
	{
		return "register";
		
	}
	
	@PostMapping("/createUser")
	public String userData(@ModelAttribute User user, HttpSession session)
	{
		System.out.println(user);
		
		boolean flag = userService.checkEmail(user.getEmail());
		
		if(flag)
		{
			session.setAttribute("msg", "Email already exist");
		}
		else
		{
			User u_details = userService.createUser(user);

			if(u_details != null)
			{
				session.setAttribute("msg", "Registration Successful");
			}
			else
			{
				session.setAttribute("msg", "Something went wrong");
			}
		}
		
		return "redirect:/register";	
	}
	
	
	
//	@RequestMapping("/login")
//	public String confirmUser(@RequestParam String email, @RequestParam String password)
//	{
//		if(email.equals("admin@gmail.com") && password.equals("admin"))
//		{
//			return "Admin/Home";
//		}
//		else
//			return "Home";
//		
//	}
	
}
