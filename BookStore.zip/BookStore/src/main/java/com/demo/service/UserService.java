package com.demo.service;

import com.demo.entity.User;

public interface UserService {

	public User createUser(User u);
	
	public boolean checkEmail(String email);
}
