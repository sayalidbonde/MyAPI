package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserRepository;
import com.demo.entity.User;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private UserRepository userRepo;

	@Override
	public User createUser(User u) {

		return userRepo.save(u);
	}

	@Override
	public boolean checkEmail(String email) {

		return userRepo.existsByEmail(email);
	}

}
